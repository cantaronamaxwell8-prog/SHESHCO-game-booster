# SHESHCO Game Space — GitHub Actions Build

Non-root Android game launcher/dashboard. This ZIP is source code; it is not a precompiled APK.

## Build from a phone using GitHub

1. Create/open your GitHub repository.
2. Extract this ZIP and upload the **contents** of the `SHESHCO_GAME_BOOSTER` folder into the repository root. The repository root should directly contain `.github/`, `app/`, `build.gradle`, and `settings.gradle`.
   - Alternatively, upload `SHESHCO_GAME_BOOSTER_MOBILE_BUILD.zip` to the repository root if you already have the workflow file at `.github/workflows/build-apk.yml`.
3. Open **Actions** → **Build SHESHCO Game Space APK** → **Run workflow**.
4. Wait for the job to finish. Download `SHESHCO-Game-Space-APK` under **Artifacts**.

## Build configuration

- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35

## Important limitations

This is a Game Space-style dashboard, not an OEM system-level game engine. A non-root app cannot guarantee CPU/GPU overclocking, force a game's FPS, read another game's true FPS in general, or change hardware touch sampling. The touch and crosshair preference controls may save settings without changing game hardware behavior. Test the APK on your own device before relying on it.
