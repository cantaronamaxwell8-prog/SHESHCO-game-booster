package com.sheshco.gamebooster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.app.ActivityManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.provider.Settings;
import android.widget.SeekBar;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class OverlayService extends Service {
    public static final String ACTION_STOP = "com.sheshco.gamebooster.STOP_OVERLAY";
    private static final String CHANNEL = "sheshco_overlay";
    private static final int NOTIFICATION_ID = 701;
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private LinearLayout panel;
    private TextView statusText;
    private final Handler handler = new Handler();
    private final Runnable updater = new Runnable() {
        @Override public void run() {
            if (statusText != null) statusText.setText(makeStatus());
            handler.postDelayed(this, 1500);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, makeNotification());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
        handler.post(updater);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (panel == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || android.provider.Settings.canDrawOverlays(this))) {
            if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            showPanel();
            handler.post(updater);
        }
        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "SHESHCO floating panel", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the optional floating game status panel available.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("SHESHCO floating panel")
                .setContentText("Showing display refresh rate and device status; not game FPS")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
    }

    private void showPanel() {
        if (windowManager == null || panel != null) return;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(9), dp(12), dp(10));
        GradientDrawable background = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(15, 29, 53), Color.rgb(7, 12, 24)});
        background.setCornerRadius(dp(16));
        background.setStroke(dp(1), Color.rgb(38, 163, 255));
        panel.setBackground(background);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("SHESHCO  •  GAME PANEL", 13, Color.rgb(85, 190, 255), true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(32), 1f));
        TextView close = label("×", 24, Color.WHITE, true);
        close.setGravity(Gravity.CENTER);
        header.addView(close, new LinearLayout.LayoutParams(dp(32), dp(32)));
        panel.addView(header);
        statusText = label(makeStatus(), 12, Color.WHITE, false);
        statusText.setLineSpacing(dp(3), 1f);
        panel.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        TextView touchTitle = label("TOUCH BOOST PRESET (app preference)", 11, Color.rgb(85, 190, 255), true);
        LinearLayout.LayoutParams touchTitleLp = new LinearLayout.LayoutParams(-1, -2);
        touchTitleLp.topMargin = dp(8);
        panel.addView(touchTitle, touchTitleLp);
        SeekBar touchSlider = new SeekBar(this);
        touchSlider.setMax(100);
        android.content.SharedPreferences prefs = getSharedPreferences("sheshco", MODE_PRIVATE);
        touchSlider.setProgress(prefs.getInt("touch_boost", 50));
        panel.addView(touchSlider, new LinearLayout.LayoutParams(-1, dp(32)));
        TextView touchNote = label("Saved preset only; Android does not expose system touch tuning to regular apps.", 10, Color.LTGRAY, false);
        panel.addView(touchNote, new LinearLayout.LayoutParams(-1, -2));
        touchSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) prefs.edit().putInt("touch_boost", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        TextView networkButton = label("NETWORK STATUS  •  OPEN INTERNET SETTINGS", 10, Color.WHITE, true);
        networkButton.setGravity(Gravity.CENTER);
        networkButton.setPadding(dp(6), dp(8), dp(6), dp(8));
        GradientDrawable netBg = new GradientDrawable();
        netBg.setColor(Color.rgb(20, 72, 110)); netBg.setCornerRadius(dp(8));
        networkButton.setBackground(netBg);
        LinearLayout.LayoutParams netLp = new LinearLayout.LayoutParams(-1, -2);
        netLp.topMargin = dp(7);
        panel.addView(networkButton, netLp);
        networkButton.setOnClickListener(v -> {
            try {
                Intent settingsIntent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(settingsIntent);
            } catch (Exception ignored) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored2) {}
            }
        });
        TextView hint = label("Drag header to move  •  × to close", 10, Color.LTGRAY, false);
        panel.addView(hint);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams = new WindowManager.LayoutParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(12);
        layoutParams.y = dp(120);

        header.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = layoutParams.x; startY = layoutParams.y;
                    touchX = event.getRawX(); touchY = event.getRawY();
                    return true;
                } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    layoutParams.x = startX + (int)(event.getRawX() - touchX);
                    layoutParams.y = startY + (int)(event.getRawY() - touchY);
                    try { windowManager.updateViewLayout(panel, layoutParams); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });
        close.setOnClickListener(v -> stopSelf());
        try { windowManager.addView(panel, layoutParams); }
        catch (Exception e) { panel = null; statusText = null; stopSelf(); }
    }

    private String makeStatus() {
        StringBuilder out = new StringBuilder();
        out.append("Refresh rate: ").append(String.format(Locale.US, "%.0f Hz", getRefreshRate())).append("\n");
        out.append("Game FPS: not readable by this non-root app\n");
        android.content.SharedPreferences prefs = getSharedPreferences("sheshco", MODE_PRIVATE);
        out.append("Mode: ").append(prefs.getString("mode", "Balance")).append("\n");
        out.append("FPS target: ").append(prefs.getInt("fps_target", 60)).append(" (preference only)\n");
        out.append("Crosshair: ").append(prefs.getString("crosshair", "•")).append("\n");
        out.append("Touch preset: ").append(prefs.getInt("touch_boost", 50)).append("/100 (saved only)\n");
        out.append("Network: ").append(getNetworkStatus()).append("\n");
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null) {
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(info);
            out.append(String.format(Locale.US, "Available RAM: %.1f GB", info.availMem / (1024.0 * 1024 * 1024)));
        } else out.append("Available RAM: unavailable");
        return out.toString();
    }


    private String getNetworkStatus() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "unavailable";
            Network active = cm.getActiveNetwork();
            if (active == null) return "disconnected";
            NetworkCapabilities caps = cm.getNetworkCapabilities(active);
            if (caps == null) return "connected (details unavailable)";
            String kind = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "Wi-Fi"
                    : caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "mobile data"
                    : caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "Ethernet" : "other network";
            return kind + (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? " • internet OK" : " • internet not verified");
        } catch (Exception e) { return "status unavailable"; }
    }

    private float getRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.view.Display display = getDisplayForStatusBar();
                if (display != null) return display.getRefreshRate();
            }
            android.view.Display display = windowManager.getDefaultDisplay();
            return display.getRefreshRate();
        } catch (Exception e) { return 0f; }
    }

    private android.view.Display getDisplayForStatusBar() {
        try { return windowManager.getDefaultDisplay(); } catch (Exception e) { return null; }
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        handler.removeCallbacks(updater);
        if (panel != null && windowManager != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
        }
        panel = null;
        statusText = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
