package com.sheshco.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 12, 24);
    private final int panel = Color.rgb(17, 26, 47);
    private final int blue = Color.rgb(38, 163, 255);
    private final int white = Color.rgb(240, 246, 255);
    private Spinner games;
    private final ArrayList<GameEntry> entries = new ArrayList<>();

    static class GameEntry {
        String label, pkg;
        GameEntry(String l, String p) { label = l; pkg = p; }
        @Override public String toString() { return label; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addGap(LinearLayout l, int h) {
        View v = new View(this);
        l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private void card(LinearLayout parent, View child) {
        LinearLayout wrap = column();
        wrap.setPadding(dp(16), dp(14), dp(16), dp(14));
        wrap.setBackgroundColor(panel);
        wrap.addView(child, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        parent.addView(wrap, p);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(white);
        b.setTextSize(15);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("SHESHCO", 31, blue, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("GAME BOOSTER  •  NON-ROOT", 13, white, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(32)));
        addGap(root, 14);

        TextView note = text("Launch games faster from one place and check your device status. No fake FPS claims, hidden tweaks, or root required.", 14, white, false);
        card(root, note);

        TextView gameTitle = text("GAME LAUNCHER", 17, white, true);
        card(root, gameTitle);
        games = new Spinner(this);
        games.setPadding(dp(4), dp(6), dp(4), dp(6));
        games.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        loadGames();
        ArrayAdapter<GameEntry> adapter = new ArrayAdapter<GameEntry>(this, android.R.layout.simple_spinner_item, entries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        games.setAdapter(adapter);
        LinearLayout gameBox = column();
        gameBox.addView(games, new LinearLayout.LayoutParams(-1, dp(52)));
        addGap(gameBox, 10);
        Button launch = button("LAUNCH SELECTED GAME");
        launch.setOnClickListener(v -> launchSelected());
        gameBox.addView(launch, new LinearLayout.LayoutParams(-1, dp(52)));
        card(root, gameBox);

        TextView statusTitle = text("DEVICE STATUS", 17, white, true);
        card(root, statusTitle);
        TextView status = text(getDeviceStatus(), 14, white, false);
        status.setLineSpacing(dp(4), 1f);
        Button refresh = button("REFRESH STATUS");
        refresh.setOnClickListener(v -> status.setText(getDeviceStatus()));
        LinearLayout statusBox = column();
        statusBox.addView(status, new LinearLayout.LayoutParams(-1, -2));
        addGap(statusBox, 12);
        statusBox.addView(refresh, new LinearLayout.LayoutParams(-1, dp(48)));
        card(root, statusBox);

        TextView settingsTitle = text("QUICK SETTINGS", 17, white, true);
        card(root, settingsTitle);
        LinearLayout settingsBox = column();
        Button display = button("DISPLAY / REFRESH RATE SETTINGS");
        display.setOnClickListener(v -> openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        settingsBox.addView(display, new LinearLayout.LayoutParams(-1, dp(50)));
        addGap(settingsBox, 8);
        Button appSettings = button("APP INFO / BATTERY SETTINGS");
        appSettings.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            safeStart(i);
        });
        settingsBox.addView(appSettings, new LinearLayout.LayoutParams(-1, dp(50)));
        card(root, settingsBox);

        TextView footer = text("Made by SHESHCO\nAndroid permissions and device firmware determine which settings are available. This app cannot force CODM FPS, change its graphics engine, or boost hardware beyond its limits.", 12, Color.rgb(170, 187, 211), false);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(dp(3), 1f);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
    }

    private void loadGames() {
        entries.clear();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, Comparator.comparing(a -> String.valueOf(a.loadLabel(pm)).toLowerCase(Locale.ROOT)));
        boolean globalFound = false, garenaFound = false;
        for (android.content.pm.ResolveInfo r : apps) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            String label = String.valueOf(r.loadLabel(pm));
            if (pkg.equals("com.activision.callofduty.shooter")) globalFound = true;
            if (pkg.equals("com.garena.game.codm")) garenaFound = true;
            entries.add(new GameEntry(label, pkg));
        }
        if (!globalFound) entries.add(0, new GameEntry("CODM Global (not detected)", "com.activision.callofduty.shooter"));
        if (!garenaFound) entries.add(0, new GameEntry("CODM Garena (not detected)", "com.garena.game.codm"));
    }

    private void launchSelected() {
        if (games == null || games.getSelectedItem() == null) return;
        GameEntry selected = (GameEntry) games.getSelectedItem();
        Intent launch = getPackageManager().getLaunchIntentForPackage(selected.pkg);
        if (launch == null) {
            Toast.makeText(this, "Game not installed or not launchable: " + selected.label, Toast.LENGTH_LONG).show();
            return;
        }
        try { startActivity(launch); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Could not launch this game.", Toast.LENGTH_SHORT).show();
        }
    }

    private String getDeviceStatus() {
        StringBuilder s = new StringBuilder();
        s.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        s.append("Device: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        try {
            float hz = getWindowManager().getDefaultDisplay().getRefreshRate();
            s.append(String.format(Locale.US, "Display refresh rate reported: %.0f Hz\n", hz));
        } catch (Exception e) { s.append("Display refresh rate: unavailable\n"); }
        ActivityManager am = (ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) {
            am.getMemoryInfo(mi);
            s.append(String.format(Locale.US, "Available RAM: %.1f GB\n", mi.availMem / (1024.0 * 1024 * 1024)));
            s.append(String.format(Locale.US, "Low-memory state: %s\n", mi.lowMemory ? "yes" : "no"));
        }
        s.append("Root access: not used\n");
        s.append("FPS measurement: not available from this app");
        return s.toString();
    }

    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Settings page is unavailable on this device.", Toast.LENGTH_SHORT).show();
        }
    }

    private void safeStart(Intent i) {
        try { startActivity(i); }
        catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Could not open Android settings.", Toast.LENGTH_SHORT).show();
        }
    }
}
