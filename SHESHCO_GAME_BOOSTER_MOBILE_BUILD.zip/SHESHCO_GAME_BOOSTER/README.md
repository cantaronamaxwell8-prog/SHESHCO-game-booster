# SHESHCO GAME BOOSTER — Android project

A lightweight, non-root Android app project for launching CODM Global, CODM Garena, and other installed apps, viewing basic device status, and opening Android display/app settings.

## Features
- SHESHCO dark-blue gaming dashboard
- Lists launchable apps and includes CODM Global/Garena shortcuts
- Launches the selected installed game
- Shows Android version, device model, reported display refresh rate, and available RAM
- Shortcuts to Android Display settings and this app's system App Info page
- No root, hidden services, game-file modification, or unsupported FPS promises

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 (Gradle sync downloads the required plugin/dependencies)

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish and install Android SDK Platform 35 if prompted.
3. Choose **Build > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important compatibility notes
- A non-root app cannot force CODM to use 90/120/165 FPS, unlock unsupported graphics settings, or switch CODM's rendering API. Game FPS depends on the game's own settings, device support, firmware, and thermal limits.
- The refresh rate shown is the current display rate reported by Android, not a measurement of game FPS.
- Android may hide some installed apps from app queries depending on OS version and manufacturer settings.
- This project is a source project, not a prebuilt APK. It must be built with Android Studio/Android SDK before installation.
