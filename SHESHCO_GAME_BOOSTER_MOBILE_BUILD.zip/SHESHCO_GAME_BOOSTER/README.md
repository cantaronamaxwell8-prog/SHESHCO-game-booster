# SHESHCO Game Booster v1.2

Ad-free, non-root Android game launcher and floating status panel.

## Added in v1.2
- Game Turbo, Balance, Power Saver, and Performance preference presets.
- 60 / 90 / 120 FPS target preference buttons (these do not force a game's actual FPS).
- Crosshair dot-style choices: dot, dot-ring, plus, cross, and ring-dot glyphs.
- Floating panel shows selected mode, target preference, crosshair style, reported display refresh rate, and available RAM.
- CODM Garena and Global launch shortcuts plus other launchable apps.

## Honest limitations
This non-root app cannot guarantee CPU/GPU overclocking, read CODM's true in-game FPS, force the game's FPS cap, or change hardware touch-sampling rate. Display refresh rate (Hz) is not the same as rendered game FPS. Crosshair glyph selection is currently a saved preference shown in the floating panel; it is not a guaranteed game-integrated reticle. Use overlays only where permitted by the game.

## Build on mobile using GitHub Actions
Upload this ZIP to your repository as `SHESHCO_GAME_BOOSTER_MOBILE_BUILD.zip` and keep `.github/workflows/build-apk.yml` in the repository root. Run the workflow in the Actions tab. The build workflow extracts this ZIP and runs `gradle assembleDebug`. Download the `SHESHCO-Game-Booster-APK` artifact after a successful build.
