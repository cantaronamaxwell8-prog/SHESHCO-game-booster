# SHESHCO Game Booster

Ad-free, non-root Android project for a lightweight game launcher and floating panel.

## Profile artwork
The main app header now uses the supplied knight-and-castle artwork as the SHESHCO profile avatar. The existing knight wallpaper remains the app background.

## Build on mobile with GitHub Actions
Upload this project ZIP to the repository as `SHESHCO_GAME_BOOSTER_MOBILE_BUILD.zip`, replacing the previous ZIP. The repository workflow extracts the project, runs `gradle assembleDebug`, and uploads the debug APK as `SHESHCO-Game-Booster-APK`.

## Limitations
Mode, FPS target, and touch boost controls are app-side preferences/shortcuts. They do not overclock the device, force a game's FPS, or directly change hardware touch sampling. A selected crosshair style is a preference unless a separate overlay renderer is implemented. Display refresh rate is not the same as game FPS.
