# SHESHCO Game Booster (non-root)

Version 1.1 adds an optional movable floating status panel.

## Features
- Launch installed games, including CODM Garena and CODM Global when installed.
- Device/Android information and available RAM.
- Shortcut to Android display settings.
- Optional floating panel over other apps, with reported display refresh rate and available RAM.
- The panel can be dragged by its header and closed with the × button.
- No ads or advertising SDKs; no root required.

## Important limitations
- Display refresh rate (Hz) is not the same as game-rendered FPS.
- A normal non-root app cannot reliably read another app's internal CODM FPS or force CODM to 90/120 FPS.
- The overlay requires Android's **Display over other apps** permission. Tap the in-app enable button, allow the permission, return to the app, and tap the button again.
- The service shows an ongoing notification while the overlay is running. Use **CLOSE FLOATING PANEL** or the × button to stop it.
- Some Android vendors may restrict background services or overlays; behavior can vary by device/firmware.

## Build
Open the project in Android Studio or run the included GitHub Actions workflow. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

This project has not been compiled or device-tested in this environment. Verify the build and test overlay permission behavior on the target phone before relying on it.
