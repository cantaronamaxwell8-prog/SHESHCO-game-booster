# SHESHCO GAME SPACE — POVA-style Game Assistant

Android source project for a non-root game dashboard and optional floating game panel. This ZIP is **source/build files**, not a compiled APK.

## GitHub Actions build (phone-friendly)

1. Extract this ZIP.
2. Upload the **contents** of `SHESHCO_GAME_BOOSTER` into the root of your GitHub repository. The root should directly show `.github/`, `app/`, `build.gradle`, and `settings.gradle`.
3. Open **Actions** → **Build SHESHCO Game Space APK** → **Run workflow**.
4. When the job succeeds, download `SHESHCO-Game-Space-APK` from the run's Artifacts section.

The workflow also supports a repository that has the ZIP `SHESHCO_GAME_BOOSTER_MOBILE_BUILD.zip` in its root, as long as this workflow is present under `.github/workflows/`.

## Implemented floating-panel tools

- Movable floating status panel (requires the user to grant Display over other apps permission).
- Refresh-rate and available-RAM information, session elapsed time, selected profile, and saved touch/crosshair preferences.
- Game Turbo profile selection (a preference only; actual performance is controlled by Android and device firmware).
- DND and display settings shortcuts, plus a session timer readout.

## Non-root limitations

Android does not let an ordinary third-party app force COD Mobile's FPS, overclock CPU/GPU, change hardware touch sampling, or read the game's true FPS. The touch and crosshair selections in this build are preferences, not system-level changes. DND shortcut opens system settings rather than silently changing protected settings. Test on your device before relying on it.

## Build toolchain

- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35


## Force Performance profile (non-root)
The dashboard and floating game panel include a Force Performance ON/OFF preference. It saves the user's selected profile and selects Performance when enabled, Balanced when disabled. It does **not** overclock CPU/GPU, change system touch sampling, disable thermal protection, or guarantee FPS gains; those are controlled by Android and the device firmware.
