# SHESHCO GAME SPACE — Dual Game Space + Floating Assistant

Android project source for Android 16 / non-root testing. This is **not** a compiled APK. It combines a Game Space dashboard with a movable floating game assistant using Android's overlay permission.

## Build on GitHub from a phone

1. Download this ZIP and extract it.
2. Open your GitHub repository in the browser.
3. Upload the **contents** of this ZIP directly to the repository root. Do not upload the enclosing folder as a single nested folder. At repository root you should see `.github`, `app`, `build.gradle`, `gradle.properties`, and `settings.gradle`.
4. Open **Actions** → **Build SHESHCO Game Space APK** → **Run workflow**.
5. When the workflow finishes with a green check, open the run and download the `SHESHCO-Game-Space-APK` artifact.

## If the old “Library file not found” message appears

This project workflow does not expect a separate library file or a ZIP extraction step. It checks for the actual Android project files and prints a direct diagnostic if any are missing. Upload the ZIP contents to repository root as described above, then run the workflow again.

## Included capabilities and limitations

- Game library/launcher and app-side game modes.
- Floating overlay panel, provided Android's “Display over other apps” permission is granted.
- Device status display (available memory and display refresh-rate information where supported).
- Shortcuts and preference controls from the existing SHESHCO source.

Because this is a non-root third-party app, it cannot guarantee CPU/GPU overclocking, force a game's FPS, or change the phone's hardware touch-sampling rate. A saved preference is not the same as a system-level change. Test the resulting APK on your own phone.
